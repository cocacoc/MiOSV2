import sys
import getpass
import random
from datetime import datetime

# Compatibilidad de teclado multiplataforma
try:
    import msvcrt  # Windows
except ImportError:
    import tty
    import termios  # Linux/Mac

class MiOS:
    def __init__(self):
        self.current_user = ""
        self.users = {"admin": "1234", "user": "4321"}
        self.running = True
        self.file_system = {
            'home': {
                'admin': {},
                'user': {}
            }
        }
        self.current_path = ['home', 'admin']
        self.editor_name = "nano"
        self.snake_score = 0

    # ======================= [MENÚ BOOT] =======================
    def boot_menu(self):
        while self.running:
            print("\n=== MiOS Boot Menu ===")
            print("1. Iniciar sistema operativo")
            print("2. Reiniciar")
            print("3. Apagar")
            choice = input("Seleccione opción: ")
            
            if choice == '1':
                self.load_kernel()
            elif choice == '2':
                print("\nReiniciando sistema...")
                self.boot_menu()
                break
            elif choice == '3':
                self.shutdown()
            else:
                print("Opción inválida")

    # ======================= [KERNEL] =======================
    def load_kernel(self):
        self.clear_screen()
        self.login()

    # ======================= [LOGIN] =======================
    def login(self):
        while True:
            user = input("Usuario: ")
            password = getpass.getpass("Contraseña: ")
            
            if self.validate_credentials(user, password):
                self.current_user = user
                self.current_path = ['home', user]
                self.shell()
                break
            else:
                print("\nError: Credenciales incorrectas!\n")

    def validate_credentials(self, user, password):
        return self.users.get(user) == password

    # ======================= [SHELL] =======================
    def shell(self):
        self.clear_screen()
        print(f"{self.current_user} conectado a MiOS v2.0")
        print("Escribe 'h' para ver los comandos disponibles\n")
        
        while True:
            current_dir = '/'.join(self.current_path)
            cmd = input(f"{self.current_user}@mios:{current_dir}$ ").strip().split()
            if not cmd:
                continue
                
            command = cmd[0].lower()
            args = cmd[1:] if len(cmd) > 1 else []
            
            commands = {
                'h': self.show_help,
                'e': lambda: self.echo(' '.join(args)),
                'c': self.clear_screen,
                's': self.shutdown,
                'l': self.logout,
                't': self.show_time,
                'a': self.calculator,
                'mkdir': lambda: self.make_directory(args),
                'ls': self.list_files,
                'cd': lambda: self.change_directory(args),
                'cat': lambda: self.read_file(args),
                'vim': lambda: self.text_editor(args),
                'nano': lambda: self.text_editor(args),
                'rm': lambda: self.remove_item(args),
                'snake': self.play_snake
            }
            
            if command in commands:
                commands[command]()
            else:
                print(f"Comando '{command}' no reconocido")

    # ===================== [SISTEMA DE ARCHIVOS] =====================
    def get_current_directory(self):
        current = self.file_system
        for part in self.current_path:
            current = current.get(part, {})
        return current

    def make_directory(self, args):
        if not args:
            print("Error: Especifique nombre del directorio")
            return
        
        dir_name = args[0]
        current_dir = self.get_current_directory()
        if dir_name in current_dir:
            print(f"Error: El directorio '{dir_name}' ya existe")
        else:
            current_dir[dir_name] = {}
            print(f"Directorio '{dir_name}' creado")

    def list_files(self):
        current_dir = self.get_current_directory()
        if not current_dir:
            print("Directorio vacío")
            return
        
        items = []
        for name, content in current_dir.items():
            items.append(f"[{name}]" if isinstance(content, dict) else name)
        print('\n'.join(items))

    def change_directory(self, args):
        if not args:
            self.current_path = ['home', self.current_user]
            return
        
        target = args[0]
        new_path = self.current_path.copy()
        
        if target == '..':
            if len(new_path) > 2:
                new_path.pop()
        else:
            current_dir = self.get_current_directory()
            if target in current_dir and isinstance(current_dir[target], dict):
                new_path.append(target)
            else:
                print(f"Error: Directorio '{target}' no encontrado")
                return
        
        self.current_path = new_path

    def read_file(self, args):
        if not args:
            print("Error: Especifique nombre del archivo")
            return
        
        filename = args[0]
        current_dir = self.get_current_directory()
        if filename in current_dir and not isinstance(current_dir[filename], dict):
            print(current_dir[filename])
        else:
            print(f"Error: Archivo '{filename}' no encontrado")

    def remove_item(self, args):
        if not args:
            print("Error: Especifique nombre del elemento")
            return
        
        name = args[0]
        current_dir = self.get_current_directory()
        if name in current_dir:
            del current_dir[name]
            print(f"'{name}' eliminado")
        else:
            print(f"Error: '{name}' no encontrado")

    # ===================== [EDITOR DE TEXTO] =====================
    def text_editor(self, args):
        if not args:
            print("Error: Especifique nombre del archivo")
            return
        
        filename = args[0]
        current_dir = self.get_current_directory()
        content = current_dir.get(filename, "") if filename in current_dir else ""
        
        print(f"\nEditando '{filename}' ({self.editor_name})")
        print("Comandos: :wq = Guardar | :q! = Salir sin guardar\n")
        
        buffer = content.split('\n') if content else []
        try:
            while True:
                for i, line in enumerate(buffer, 1):
                    print(f"{i:3}| {line}")
                new_line = input().strip()
                
                if new_line == ':wq':
                    current_dir[filename] = '\n'.join(buffer)
                    print(f"Archivo '{filename}' guardado")
                    break
                elif new_line == ':q!':
                    print("Cambios descartados")
                    break
                else:
                    buffer.append(new_line)
        except KeyboardInterrupt:
            print("\nEdición cancelada")

    # ===================== [JUEGO SNAKE] =====================
    def play_snake(self):
        self.clear_screen()
        print("Snake Game - WASD para mover | Q para salir")
        print(f"Puntuación: {self.snake_score}")
        
        snake = [(10, 15), (10, 14), (10, 13)]
        food = self.generate_food(snake)
        direction = 'd'
        
        try:
            while True:
                self.draw_game(snake, food)
                key = self.get_key()
                
                if key == 'q':
                    break
                
                direction = self.update_direction(direction, key)
                new_head = self.move_snake(snake[0], direction)
                
                if self.check_collision(new_head, snake):
                    raise KeyboardInterrupt
                
                snake.insert(0, new_head)
                if new_head == food:
                    self.snake_score += 10
                    food = self.generate_food(snake)
                else:
                    snake.pop()
                    
        except KeyboardInterrupt:
            print("\n¡Game Over! Puntuación final:", self.snake_score)
            self.snake_score = 0
            input("Presiona Enter para continuar...")
            self.clear_screen()

    def generate_food(self, snake):
        while True:
            food = (random.randint(2, 19), random.randint(2, 39))
            if food not in snake:
                return food

    def draw_game(self, snake, food):
        self.clear_screen()
        board = [[' ' for _ in range(42)] for _ in range(22)]
        
        # Bordes
        for x in range(42):
            board[0][x] = board[21][x] = '█'
        for y in range(22):
            board[y][0] = board[y][41] = '█'
        
        # Serpiente
        for y, x in snake:
            board[y][x] = '■' if (y, x) == snake[0] else '○'
        
        # Comida
        board[food[0]][food[1]] = '★'
        
        # Dibujar
        print(f"Puntuación: {self.snake_score}")
        for row in board:
            print(''.join(row))

    def get_key(self):
        try:
            if 'msvcrt' in sys.modules:
                return msvcrt.getch().decode().lower() if msvcrt.kbhit() else ''
            else:
                fd = sys.stdin.fileno()
                old = termios.tcgetattr(fd)
                try:
                    tty.setraw(fd)
                    return sys.stdin.read(1).lower()
                finally:
                    termios.tcsetattr(fd, termios.TCSADRAIN, old)
        except:
            return ''

    def update_direction(self, current, key):
        directions = {
            'w': 'u' if current != 'd' else current,
            's': 'd' if current != 'u' else current,
            'a': 'l' if current != 'r' else current,
            'd': 'r' if current != 'l' else current
        }
        return directions.get(key, current)

    def move_snake(self, head, direction):
        y, x = head
        return {
            'u': (y-1, x),
            'd': (y+1, x),
            'l': (y, x-1),
            'r': (y, x+1)
        }[direction]

    def check_collision(self, head, snake):
        return (head[0] in (0, 21) or
                head[1] in (0, 41) or
                head in snake[1:])

    # ===================== [COMANDOS BÁSICOS] =====================
    def logout(self):
        self.current_user = ""
        self.current_path = ['home', 'admin']
        self.clear_screen()
        self.login()

    def clear_screen(self):
        print("\033c", end="")  # Secuencia ANSI para limpiar pantalla

    def show_help(self):
        help_text = """
Comandos disponibles:
  h         Muestra esta ayuda
  e <texto> Imprime texto
  c         Limpia la pantalla
  s         Apaga el sistema
  l         Cierra sesión
  t         Muestra la hora actual
  a         Abre la calculadora
  mkdir     Crea un directorio
  ls        Lista archivos
  cd        Cambia de directorio
  cat       Muestra contenido de archivo
  vim/nano  Editor de texto
  rm        Elimina archivo/directorio
  snake     Juego Snake clásico
"""
        print(help_text)

    def echo(self, text):
        print(text)

    def shutdown(self):
        print("\nSistema apagado")
        self.running = False
        sys.exit(0)

    def show_time(self):
        now = datetime.now().strftime("%H:%M:%S")
        print(f"Hora actual del sistema: {now}")

    # ===================== [CALCULADORA] =====================
    def calculator(self):
        try:
            num1 = float(input("Ingrese primer número: "))
            oper = input("Operación (+, -, *, /): ")
            num2 = float(input("Ingrese segundo número: "))
            
            operations = {
                '+': lambda a,b: a+b,
                '-': lambda a,b: a-b,
                '*': lambda a,b: a*b,
                '/': lambda a,b: a/b
            }
            
            if oper not in operations:
                raise ValueError("Operador inválido")
                
            result = operations[oper](num1, num2)
            print(f"Resultado: {result:.2f}")
            
        except ZeroDivisionError:
            print("Error: División por cero")
        except:
            print("Error: Operación inválida")

if __name__ == "__main__":
    os = MiOS()
    os.boot_menu()